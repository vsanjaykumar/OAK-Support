<?php

return array(
    'id'          => 'osticket:slack',
    'version'     => '0.2',
    'name'        => 'Slack notifier',
    'author'      => 'Thammanna Jammada',
    'description' => 'Notify Slack on new ticket.',
    'url'         => 'https://github.com/thammanna/osticket-slack',
    'plugin'      => 'slack.php:SlackPlugin',
);
